
package epochjva.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import epochjva.init.EpochModItems;
import epochjva.init.EpochModFluids;
import epochjva.init.EpochModFluidTypes;
import epochjva.init.EpochModBlocks;

public abstract class HotAirFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> EpochModFluidTypes.HOT_AIR_TYPE.get(), () -> EpochModFluids.HOT_AIR.get(), () -> EpochModFluids.FLOWING_HOT_AIR.get()).explosionResistance(0f)
			.tickRate(1).slopeFindDistance(1).bucket(() -> EpochModItems.HOT_AIR_BUCKET.get()).block(() -> (LiquidBlock) EpochModBlocks.HOT_AIR.get());

	private HotAirFluid() {
		super(PROPERTIES);
	}

	public static class Source extends HotAirFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends HotAirFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
