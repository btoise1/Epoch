package epochjva.procedures;

import net.minecraft.world.entity.Entity;

import epochjva.network.EpochModVariables;

public class TempResetProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = 20;
			entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.LocalTemperature = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
