package epochjva.procedures;

import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

import java.util.concurrent.atomic.AtomicBoolean;

import epochjva.init.EpochModBlocks;

public class StillAirNeighbourBlockChangesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double AirCount = 0;
		double xx = 0;
		double yy = 0;
		double zz = 0;
		if (world.canSeeSkyFromBelowWater(BlockPos.containing(x, y, z))) {
			world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
		} else {
			if ((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			if ((world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			if ((world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			if ((world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			if ((world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == Blocks.AIR) {
				AirCount = AirCount + 1;
			}
			xx = Mth.nextInt(RandomSource.create(), -1, 1);
			yy = Mth.nextInt(RandomSource.create(), -1, 1);
			zz = Mth.nextInt(RandomSource.create(), -1, 1);
			if (AirCount >= 4) {
				world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
			} else if ((new Object() {
				public boolean canExtractEnergy(LevelAccessor level, BlockPos pos) {
					AtomicBoolean _retval = new AtomicBoolean(false);
					BlockEntity _ent = level.getBlockEntity(pos);
					if (_ent != null)
						_ent.getCapability(ForgeCapabilities.ENERGY, null).ifPresent(capability -> _retval.set(capability.canExtract()));
					return _retval.get();
				}
			}.canExtractEnergy(world, BlockPos.containing(x - xx, y - yy, z - zz))) == false && (world.getBlockState(BlockPos.containing(x - xx, y - yy, z - zz))).getBlock() == Blocks.AIR) {
				world.setBlock(BlockPos.containing(x - xx, y - yy, z - zz), EpochModBlocks.STILL_AIRR.get().defaultBlockState(), 3);
			}
		}
	}
}
