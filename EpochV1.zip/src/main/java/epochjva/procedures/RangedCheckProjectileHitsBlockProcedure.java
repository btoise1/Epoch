package epochjva.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import epochjva.init.EpochModBlocks;

public class RangedCheckProjectileHitsBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double HitY = 0;
		double HitX = 0;
		double HitZ = 0;
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.AIR) {
			world.setBlock(BlockPos.containing(x, y, z), EpochModBlocks.STILL_AIRR.get().defaultBlockState(), 3);
		} else {
			if (!entity.level().isClientSide())
				entity.discard();
		}
	}
}
