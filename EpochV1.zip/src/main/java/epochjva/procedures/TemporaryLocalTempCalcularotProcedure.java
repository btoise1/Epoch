package epochjva.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import epochjva.network.EpochModVariables;

import epochjva.init.EpochModBlocks;

@Mod.EventBusSubscriber
public class TemporaryLocalTempCalcularotProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player.getX(), event.player.getY(), event.player.getZ(), event.player);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double outputSunxposed = 0;
		double ShelteredFromSun = 0;
		double RainAndWater = 0;
		if (world.canSeeSkyFromBelowWater(BlockPos.containing(x, y, z)) == true) {
			outputSunxposed = (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).InitialBiomeTemperature
					+ (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureLight;
			{
				double _setval = outputSunxposed;
				entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.LocalTemperature = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if (entity.isInWaterRainOrBubble()) {
				{
					double _setval = ((entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureDrenched + outputSunxposed) / 2;
					entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.LocalTemperature = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		} else {
			ShelteredFromSun = ((entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).InitialBiomeTemperature
					+ (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureLight
					+ (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureShade) / 2;
			{
				double _setval = ShelteredFromSun;
				entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.LocalTemperature = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
		if (entity.isInWaterRainOrBubble()) {
			RainAndWater = ((entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).InitialBiomeTemperature
					+ (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureLight)
					- (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureDrenched;
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == EpochModBlocks.STILL_AIRR.get() || (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == EpochModBlocks.STILL_AIRR.get()) {
			{
				double _setval = ((entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).LocalTemperature + 20) / 2;
				entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.LocalTemperature = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
