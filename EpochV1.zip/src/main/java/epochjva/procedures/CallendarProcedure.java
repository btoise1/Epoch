package epochjva.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

import epochjva.network.EpochModVariables;

@Mod.EventBusSubscriber
public class CallendarProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level(), event.player);
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).Time == 20000) {
			if (EpochModVariables.WorldVariables.get(world).Date < 52) {
				EpochModVariables.WorldVariables.get(world).Date = EpochModVariables.WorldVariables.get(world).Date + 1;
				EpochModVariables.WorldVariables.get(world).syncData(world);
				EpochModVariables.WorldVariables.get(world).ForCallendar = ("Day" + EpochModVariables.WorldVariables.get(world).Date) + "" + ("Year" + EpochModVariables.WorldVariables.get(world).writtendate2);
				EpochModVariables.WorldVariables.get(world).syncData(world);
			} else {
				EpochModVariables.WorldVariables.get(world).Date = 1;
				EpochModVariables.WorldVariables.get(world).syncData(world);
				EpochModVariables.WorldVariables.get(world).writtendate2 = EpochModVariables.WorldVariables.get(world).writtendate2 + 1;
				EpochModVariables.WorldVariables.get(world).syncData(world);
			}
		}
	}
}
