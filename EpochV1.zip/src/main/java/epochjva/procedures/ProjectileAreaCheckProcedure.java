package epochjva.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import epochjva.init.EpochModEntities;

import epochjva.entity.RangedCheckEntity;

public class ProjectileAreaCheckProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		for (int index0 = 0; index0 < 32; index0++) {
			if (world instanceof ServerLevel projectileLevel) {
				Projectile _entityToSpawn = new Object() {
					public Projectile getArrow(Level level, float damage, int knockback, byte piercing) {
						AbstractArrow entityToSpawn = new RangedCheckEntity(EpochModEntities.RANGED_CHECK.get(), level);
						entityToSpawn.setBaseDamage(damage);
						entityToSpawn.setKnockback(knockback);
						entityToSpawn.setSilent(true);
						entityToSpawn.setPierceLevel(piercing);
						return entityToSpawn;
					}
				}.getArrow(projectileLevel, 0, 0, (byte) 4);
				_entityToSpawn.setPos(x, y, z);
				_entityToSpawn.shoot((Mth.nextInt(RandomSource.create(), 0, 360)), (Mth.nextInt(RandomSource.create(), 0, 360)), (Mth.nextInt(RandomSource.create(), 0, 360)), 20, 0);
				projectileLevel.addFreshEntity(_entityToSpawn);
			}
		}
	}
}
