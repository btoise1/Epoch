package epochjva.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;

import epochjva.network.EpochModVariables;

@Mod.EventBusSubscriber
public class CallTempCommandProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player);
		}
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && !_player.level().isClientSide())
			_player.displayClientMessage(Component.literal((((("Biome:" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).InitialBiomeTemperature) + ""
					+ ("IsCheckkerPresent:" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).IsCheckerPresent)) + ""
					+ ("Shade:" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureShade))
					+ ""
					+ (("Drenched:" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureDrenched) + ""
							+ (("LightLevel" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).TemperatureLight) + ""
									+ (("Time" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).Time) + ""
											+ ("You" + (entity.getCapability(EpochModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new EpochModVariables.PlayerVariables())).LocalTemperature)))))),
					true);
	}
}
