
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package epochjva.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import epochjva.block.StillAirrBlock;
import epochjva.block.HotAirBlock;
import epochjva.block.GreyRoofTileStairsBlock;
import epochjva.block.GreyRoofTileSlabBlock;
import epochjva.block.GreyRoofTileBlock;

import epochjva.EpochMod;

public class EpochModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, EpochMod.MODID);
	public static final RegistryObject<Block> GREY_ROOF_TILE_SLAB = REGISTRY.register("grey_roof_tile_slab", () -> new GreyRoofTileSlabBlock());
	public static final RegistryObject<Block> GREY_ROOF_TILE = REGISTRY.register("grey_roof_tile", () -> new GreyRoofTileBlock());
	public static final RegistryObject<Block> GREY_ROOF_TILE_STAIRS = REGISTRY.register("grey_roof_tile_stairs", () -> new GreyRoofTileStairsBlock());
	public static final RegistryObject<Block> HOT_AIR = REGISTRY.register("hot_air", () -> new HotAirBlock());
	public static final RegistryObject<Block> STILL_AIRR = REGISTRY.register("still_airr", () -> new StillAirrBlock());
}
