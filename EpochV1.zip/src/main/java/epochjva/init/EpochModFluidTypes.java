
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package epochjva.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import epochjva.fluid.types.HotAirFluidType;

import epochjva.EpochMod;

public class EpochModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, EpochMod.MODID);
	public static final RegistryObject<FluidType> HOT_AIR_TYPE = REGISTRY.register("hot_air", () -> new HotAirFluidType());
}
