
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package epochjva.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import epochjva.item.RangedCheckItem;
import epochjva.item.HotAirItem;

import epochjva.EpochMod;

public class EpochModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EpochMod.MODID);
	public static final RegistryObject<Item> GREY_ROOF_TILE_SLAB = block(EpochModBlocks.GREY_ROOF_TILE_SLAB);
	public static final RegistryObject<Item> GREY_ROOF_TILE = block(EpochModBlocks.GREY_ROOF_TILE);
	public static final RegistryObject<Item> GREY_ROOF_TILE_STAIRS = block(EpochModBlocks.GREY_ROOF_TILE_STAIRS);
	public static final RegistryObject<Item> TARGET_SPAWN_EGG = REGISTRY.register("target_spawn_egg", () -> new ForgeSpawnEggItem(EpochModEntities.TARGET, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> RANGED_CHECK = REGISTRY.register("ranged_check", () -> new RangedCheckItem());
	public static final RegistryObject<Item> HOT_AIR_BUCKET = REGISTRY.register("hot_air_bucket", () -> new HotAirItem());
	public static final RegistryObject<Item> STILL_AIRR = block(EpochModBlocks.STILL_AIRR);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
